// Fix mobile menu text
document.addEventListener('DOMContentLoaded', function() {
    const mobileMenuTexts = {
        'mobileRefreshBtn': 'Refresh Data',
        'mobileSearchBtn': 'Quick Search', 
        'mobileDbBtn': 'Database',
        'mobileExportBtn': 'Export Excel',
        'mobileDownloadBtn': 'Download All',
        'mobileExitBtn': 'Exit'
    };
    
    Object.keys(mobileMenuTexts).forEach(id => {
        const btn = document.getElementById(id);
        if (btn) {
            const span = btn.querySelector('span');
            if (span) {
                span.textContent = mobileMenuTexts[id];
            }
        }
    });
});